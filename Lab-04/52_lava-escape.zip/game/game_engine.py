import pygame
import math

from game.player import Player

from game.world import (
    generate_platforms,
    draw_lava,
    draw_platform
)


WIDTH = 500
HEIGHT = 640

FPS = 60

BG = (
    20,
    15,
    30
)

GROUND_Y = HEIGHT + 200


class GameEngine:

    def __init__(self):

        pygame.init()

        self.screen = pygame.display.set_mode(
            (
                WIDTH,
                HEIGHT
            )
        )

        pygame.display.set_caption(
            "Lava Escape"
        )

        self.clock = pygame.time.Clock()

        self.font = pygame.font.SysFont(
            "monospace",
            24,
            bold=True
        )

        self.small_font = pygame.font.SysFont(
            "monospace",
            16,
            bold=True
        )

        self.big_font = pygame.font.SysFont(
            "monospace",
            42,
            bold=True
        )

        self.reset()

    def reset(self):

        self.platforms = generate_platforms(
            WIDTH,
            GROUND_Y
        )

        self.player = Player(
            WIDTH // 2 - 16,
            GROUND_Y - 50
        )

        self.cam_y = 0

        self.lava_y = GROUND_Y + 60

        # Base lava speed.
        self.lava_rise = 0.4

        self.score = 0

        self.game_over = False
        self.won = False

        self.top_y = self.platforms[-1].y

        self.frame = 0

        # =================================================
        # TASK 2:
        # CRUMBLING PLATFORM STATE
        # =================================================

        self.fragile_platforms = set()

        for i, platform in enumerate(
            self.platforms[1:],
            start=1
        ):

            # Every fourth elevated platform
            # is fragile.
            if i % 4 == 0:

                self.fragile_platforms.add(
                    id(platform)
                )

        self.crumble_timers = {}

        self.crumble_start_frames = {}

        # =================================================
        # TASK 3:
        # SPRING PLATFORM STATE
        # =================================================

        self.spring_platforms = set()

        for i, platform in enumerate(
            self.platforms[1:],
            start=1
        ):

            # Every fifth platform is a spring.
            #
            # Avoid making it fragile and spring
            # at the same time.
            if (
                i % 5 == 0
                and i % 4 != 0
            ):

                self.spring_platforms.add(
                    id(platform)
                )

        # =================================================
        # TASK 4:
        # LAVA SURGE STATE
        # =================================================

        # Number of frames between surge phases.
        self.surge_interval = 600

        # Duration of each surge.
        self.surge_duration = 180

        # Extra lava speed during a surge.
        self.surge_bonus = 0.9

        self.surge_active = False

        self.surge_remaining = 0

        self.next_surge_frame = (
            self.surge_interval
        )

    def handle_events(self):

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return False

            if (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_r
            ):

                self.reset()

        return True

    def update(self):

        if (
            self.game_over
            or self.won
        ):

            return

        keys = pygame.key.get_pressed()

        # =================================================
        # PLAYER
        # =================================================

        self.player.update(
            keys,
            self.platforms,
            WIDTH,
            self.spring_platforms
        )

        # =================================================
        # TASK 2:
        # CRUMBLING PLATFORMS
        # =================================================

        landed_platform = (
            self.player.last_landed_platform
        )

        if landed_platform is not None:

            platform_id = id(
                landed_platform
            )

            if (
                platform_id
                in self.fragile_platforms
            ):

                if (
                    platform_id
                    not in self.crumble_timers
                ):

                    # 90 frames = 1.5 seconds
                    # at 60 FPS.
                    self.crumble_timers[
                        platform_id
                    ] = 90

                    self.crumble_start_frames[
                        platform_id
                    ] = self.frame

        # Update crumble timers.
        platforms_to_remove = []

        for platform_id in list(
            self.crumble_timers.keys()
        ):

            self.crumble_timers[
                platform_id
            ] -= 1

            if (
                self.crumble_timers[
                    platform_id
                ] <= 0
            ):

                platforms_to_remove.append(
                    platform_id
                )

        # Remove destroyed platforms.
        for platform_id in platforms_to_remove:

            self.platforms = [
                p
                for p in self.platforms
                if id(p) != platform_id
            ]

            self.fragile_platforms.discard(
                platform_id
            )

            self.spring_platforms.discard(
                platform_id
            )

            self.crumble_timers.pop(
                platform_id,
                None
            )

            self.crumble_start_frames.pop(
                platform_id,
                None
            )

        # =================================================
        # CAMERA
        # =================================================

        target = (
            self.player.rect.centery
            - HEIGHT // 2
        )

        if target < self.cam_y:

            self.cam_y = target

        # =================================================
        # TASK 4:
        # LAVA SURGE SYSTEM
        # =================================================

        # Start a new surge periodically.
        if (
            not self.surge_active
            and self.frame >= self.next_surge_frame
        ):

            self.surge_active = True

            self.surge_remaining = (
                self.surge_duration
            )

        # Apply surge.
        if self.surge_active:

            self.surge_remaining -= 1

            if self.surge_remaining <= 0:

                self.surge_active = False

                self.next_surge_frame = (
                    self.frame
                    + self.surge_interval
                )

        # =================================================
        # TASK 4:
        # CALCULATE CURRENT LAVA SPEED
        # =================================================

        # Gradually increase the normal lava speed.
        self.lava_rise = min(
            1.2,
            self.lava_rise + 0.0003
        )

        current_lava_speed = (
            self.lava_rise
        )

        # Add temporary surge speed.
        if self.surge_active:

            current_lava_speed += (
                self.surge_bonus
            )

        # Move lava upward.
        self.lava_y -= current_lava_speed

        # =================================================
        # SCORE
        # =================================================

        self.score = max(
            0,
            (
                GROUND_Y
                - self.player.rect.y
            ) // 10
        )

        self.frame += 1

        # =================================================
        # GAME OVER
        # =================================================

        if (
            self.player.rect.bottom
            >= self.lava_y
        ):

            self.game_over = True

        # =================================================
        # VICTORY
        # =================================================

        if (
            self.player.rect.top
            <= self.top_y - 20
        ):

            self.won = True

    def draw(self):

        self.screen.fill(BG)

        # =================================================
        # PLATFORMS
        # =================================================

        for p in self.platforms:

            platform_id = id(p)

            fragile = (
                platform_id
                in self.fragile_platforms
            )

            spring = (
                platform_id
                in self.spring_platforms
            )

            shake = 0

            # Task 2:
            # Shake fragile platforms after landing.
            if (
                fragile
                and platform_id
                in self.crumble_timers
            ):

                remaining = (
                    self.crumble_timers[
                        platform_id
                    ]
                )

                if remaining > 30:

                    intensity = 2

                else:

                    intensity = 4

                shake = int(
                    math.sin(
                        self.frame * 1.5
                    ) * intensity
                )

            draw_platform(
                self.screen,
                p,
                self.cam_y,
                fragile=fragile,
                spring=spring,
                shake=shake
            )

        # =================================================
        # PLAYER
        # =================================================

        self.player.draw(
            self.screen,
            self.cam_y
        )

        # =================================================
        # LAVA
        # =================================================

        draw_lava(
            self.screen,
            self.lava_y,
            self.cam_y,
            WIDTH,
            HEIGHT,
            self.frame
        )

        # =================================================
        # TASK 4:
        # DANGER HUD
        # =================================================

        self.draw_danger_hud()

        # =================================================
        # HEIGHT HUD
        # =================================================

        sc = self.font.render(
            f"Height: {self.score}m",
            True,
            (
                220,
                200,
                180
            )
        )

        self.screen.blit(
            sc,
            (
                8,
                10
            )
        )

        # Restart instruction.
        restart_text = self.small_font.render(
            "R = Restart",
            True,
            (
                200,
                200,
                200
            )
        )

        self.screen.blit(
            restart_text,
            (
                8,
                38
            )
        )

        # =================================================
        # SURGE WARNING
        # =================================================

        if self.surge_active:

            warning = self.font.render(
                "!!! LAVA SURGE !!!",
                True,
                (
                    255,
                    220,
                    80
                )
            )

            self.screen.blit(
                warning,
                (
                    WIDTH // 2
                    - warning.get_width() // 2,
                    45
                )
            )

        # =================================================
        # GAME OVER
        # =================================================

        if self.game_over:

            self._msg(
                "LAVA GOT YOU!",
                (
                    220,
                    80,
                    40
                )
            )

        # =================================================
        # VICTORY
        # =================================================

        if self.won:

            self._msg(
                "ESCAPED!",
                (
                    80,
                    220,
                    100
                )
            )

        pygame.display.flip()

    def draw_danger_hud(self):

        # ---------------------------------------------
        # Current lava speed
        # ---------------------------------------------

        speed = self.lava_rise

        if self.surge_active:

            speed += self.surge_bonus

        # ---------------------------------------------
        # Convert speed into 0-100 danger percentage.
        #
        # Maximum expected speed:
        # 1.2 normal + 0.9 surge = 2.1
        # ---------------------------------------------

        danger = int(
            min(
                100,
                (speed / 2.1) * 100
            )
        )

        # ---------------------------------------------
        # Meter dimensions
        # ---------------------------------------------

        meter_width = 180
        meter_height = 18

        meter_x = (
            WIDTH
            - meter_width
            - 15
        )

        meter_y = 12

        # Background.
        pygame.draw.rect(
            self.screen,
            (
                50,
                40,
                40
            ),
            (
                meter_x,
                meter_y,
                meter_width,
                meter_height
            ),
            border_radius=4
        )

        # Filled portion.
        fill_width = int(
            meter_width
            * danger
            / 100
        )

        # Use different danger levels.
        if danger < 40:

            meter_color = (
                80,
                200,
                100
            )

        elif danger < 70:

            meter_color = (
                230,
                190,
                70
            )

        else:

            meter_color = (
                230,
                70,
                50
            )

        if fill_width > 0:

            pygame.draw.rect(
                self.screen,
                meter_color,
                (
                    meter_x,
                    meter_y,
                    fill_width,
                    meter_height
                ),
                border_radius=4
            )

        # Border.
        pygame.draw.rect(
            self.screen,
            (
                220,
                200,
                180
            ),
            (
                meter_x,
                meter_y,
                meter_width,
                meter_height
            ),
            2,
            border_radius=4
        )

        # Label.
        label = self.small_font.render(
            f"DANGER {danger}%",
            True,
            (
                230,
                220,
                210
            )
        )

        self.screen.blit(
            label,
            (
                meter_x,
                meter_y + meter_height + 3
            )
        )

    def _msg(
        self,
        text,
        color
    ):

        ov = pygame.Surface(
            (
                WIDTH,
                HEIGHT
            ),
            pygame.SRCALPHA
        )

        ov.fill(
            (
                0,
                0,
                0,
                150
            )
        )

        self.screen.blit(
            ov,
            (
                0,
                0
            )
        )

        m = self.big_font.render(
            text,
            True,
            color
        )

        s = self.font.render(
            "Press R to Play Again",
            True,
            (
                200,
                200,
                200
            )
        )

        self.screen.blit(
            m,
            (
                WIDTH // 2
                - m.get_width() // 2,
                HEIGHT // 2 - 40
            )
        )

        self.screen.blit(
            s,
            (
                WIDTH // 2
                - s.get_width() // 2,
                HEIGHT // 2 + 20
            )
        )

    def run(self):

        running = True

        while running:

            running = self.handle_events()

            self.update()

            self.draw()

            self.clock.tick(FPS)

        pygame.quit()