import pygame
import random
import math


PLATFORM_COLOR = (100, 80, 50)
FRAGILE_PLATFORM_COLOR = (180, 120, 50)
SPRING_PLATFORM_COLOR = (60, 170, 100)

LAVA_COLOR = (220, 60, 20)


def generate_platforms(width, base_y, count=30):

    plats = [
        pygame.Rect(
            0,
            base_y,
            width,
            20
        )
    ]

    y = base_y - 110

    for i in range(count):

        w = random.randint(
            80,
            200
        )

        x = random.randint(
            0,
            width - w
        )

        platform = pygame.Rect(
            x,
            y,
            w,
            16
        )

        plats.append(platform)

        y -= random.randint(
            80,
            130
        )

    return plats


def draw_platform(
    screen,
    platform,
    cam_y,
    fragile=False,
    spring=False,
    shake=0
):
    """
    Draw a normal, fragile, or spring platform.
    """

    x = platform.x
    y = platform.y - int(cam_y)

    # ---------------------------------------------
    # Task 2:
    # Shake fragile platforms.
    # ---------------------------------------------

    if fragile:
        x += shake

    rect = pygame.Rect(
        x,
        y,
        platform.width,
        platform.height
    )

    # ---------------------------------------------
    # Task 3:
    # Spring platform
    # ---------------------------------------------

    if spring:

        pygame.draw.rect(
            screen,
            SPRING_PLATFORM_COLOR,
            rect,
            border_radius=4
        )

        # Draw spring coils.
        spring_y = y + platform.height // 2

        points = []

        coil_width = min(
            platform.width - 10,
            60
        )

        start_x = (
            x
            + platform.width // 2
            - coil_width // 2
        )

        for i in range(7):

            coil_x = (
                start_x
                + i * coil_width / 6
            )

            coil_y = (
                spring_y
                + (3 if i % 2 == 0 else -3)
            )

            points.append(
                (
                    int(coil_x),
                    int(coil_y)
                )
            )

        if len(points) > 1:

            pygame.draw.lines(
                screen,
                (230, 240, 180),
                False,
                points,
                2
            )

        # Upward arrow.
        arrow_x = (
            x
            + platform.width // 2
        )

        pygame.draw.line(
            screen,
            (240, 240, 180),
            (
                arrow_x,
                y - 2
            ),
            (
                arrow_x,
                y - 10
            ),
            2
        )

        pygame.draw.line(
            screen,
            (240, 240, 180),
            (
                arrow_x,
                y - 10
            ),
            (
                arrow_x - 4,
                y - 5
            ),
            2
        )

        pygame.draw.line(
            screen,
            (240, 240, 180),
            (
                arrow_x,
                y - 10
            ),
            (
                arrow_x + 4,
                y - 5
            ),
            2
        )

    # ---------------------------------------------
    # Task 2:
    # Fragile platform
    # ---------------------------------------------

    elif fragile:

        pygame.draw.rect(
            screen,
            FRAGILE_PLATFORM_COLOR,
            rect,
            border_radius=4
        )

        # Crack 1.
        pygame.draw.line(
            screen,
            (80, 50, 20),
            (
                x + platform.width // 3,
                y + 3
            ),
            (
                x + platform.width // 2,
                y + platform.height - 3
            ),
            2
        )

        # Crack 2.
        pygame.draw.line(
            screen,
            (80, 50, 20),
            (
                x + platform.width // 2,
                y + platform.height // 2
            ),
            (
                x + platform.width * 2 // 3,
                y + 2
            ),
            2
        )

    # ---------------------------------------------
    # Normal platform
    # ---------------------------------------------

    else:

        pygame.draw.rect(
            screen,
            PLATFORM_COLOR,
            rect,
            border_radius=4
        )


def draw_lava(
    screen,
    lava_y,
    cam_y,
    width,
    height,
    frame
):

    ly = int(
        lava_y - cam_y
    )

    if ly < height:

        # Lava surface wave.
        pts = [
            (0, ly)
        ]

        for x in range(
            0,
            width + 20,
            20
        ):

            pts.append(
                (
                    x,
                    ly
                    + int(
                        math.sin(
                            x * 0.08
                            + frame * 0.1
                        ) * 8
                    )
                )
            )

        pts.append(
            (
                width,
                height
            )
        )

        pts.append(
            (
                0,
                height
            )
        )

        pygame.draw.polygon(
            screen,
            LAVA_COLOR,
            pts
        )

        # Lava glow.
        s = pygame.Surface(
            (
                width,
                30
            ),
            pygame.SRCALPHA
        )

        for i in range(15):

            pygame.draw.line(
                s,
                (
                    255,
                    100,
                    0,
                    max(
                        0,
                        60 - i * 4
                    )
                ),
                (
                    0,
                    i
                ),
                (
                    width,
                    i
                ),
                1
            )

        screen.blit(
            s,
            (
                0,
                ly - 15
            )
        )