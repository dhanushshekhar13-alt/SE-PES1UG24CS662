import pygame

SPEED = 4

# Normal jump velocity
NORMAL_JUMP_VELOCITY = -13

# Spring platform launch velocity
SPRING_JUMP_VELOCITY = -20


class Player:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 32, 32)
        self.vel_y = 0
        self.on_ground = False

        # Stores the platform landed on during the current frame.
        self.last_landed_platform = None

        self.color = (60, 160, 220)

    def update(
        self,
        keys,
        platforms,
        width,
        spring_platforms=None
    ):
        if spring_platforms is None:
            spring_platforms = set()

        dx = 0

        # ---------------------------------------------
        # Horizontal movement
        # ---------------------------------------------

        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx = -SPEED

        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx = SPEED

        # ---------------------------------------------
        # Normal jump
        # ---------------------------------------------

        if (
            keys[pygame.K_SPACE]
            or keys[pygame.K_w]
            or keys[pygame.K_UP]
        ) and self.on_ground:

            self.vel_y = NORMAL_JUMP_VELOCITY
            self.on_ground = False

        # ---------------------------------------------
        # Gravity
        # ---------------------------------------------

        self.vel_y = min(
            self.vel_y + 0.55,
            12
        )

        # ---------------------------------------------
        # Horizontal movement
        # ---------------------------------------------

        self.rect.x = max(
            0,
            min(
                width - self.rect.width,
                self.rect.x + dx
            )
        )

        # ---------------------------------------------
        # Task 1:
        # Remember player's position before movement
        # ---------------------------------------------

        previous_bottom = self.rect.bottom

        # ---------------------------------------------
        # Vertical movement
        # ---------------------------------------------

        self.rect.y += int(self.vel_y)

        self.on_ground = False
        self.last_landed_platform = None

        # ---------------------------------------------
        # Task 1:
        # One-way platform collision
        #
        # The player can pass through the bottom.
        # Landing only happens while descending and
        # when the player crosses the platform's top.
        # ---------------------------------------------

        if self.vel_y > 0:

            for p in platforms:

                horizontal_overlap = (
                    self.rect.right > p.left
                    and self.rect.left < p.right
                )

                crossed_platform_top = (
                    previous_bottom <= p.top
                    and self.rect.bottom >= p.top
                )

                if (
                    horizontal_overlap
                    and crossed_platform_top
                ):

                    # Place player exactly on platform.
                    self.rect.bottom = p.top

                    # ---------------------------------
                    # Task 3:
                    # Spring platform
                    # ---------------------------------

                    if id(p) in spring_platforms:

                        self.vel_y = SPRING_JUMP_VELOCITY
                        self.on_ground = False

                    else:

                        self.vel_y = 0
                        self.on_ground = True

                    self.last_landed_platform = p

                    break

    def draw(self, screen, cam_y):

        dr = self.rect.move(
            0,
            -int(cam_y)
        )

        pygame.draw.rect(
            screen,
            self.color,
            dr,
            border_radius=6
        )

        pygame.draw.circle(
            screen,
            (255, 220, 180),
            (
                dr.centerx,
                dr.top + 8
            ),
            7
        )