# Reflection

## 1. Which issues were the easiest to fix, and which were the hardest? Why?

The easiest were the style and formatting issues from Flake8 and Pylint: unused imports and variables, `== None`, missing final newline, long lines, and snake_case renames. Each warning points at an exact line and the fix is mechanical.

The hardest was the `eval()` call in the scholarship calculation. Removing `eval` meant changing the function's interface: instead of accepting an arbitrary expression like `"base_fee * 0.75"`, it now accepts a numeric discount rate and validates it. I had to make sure the output stayed the same (450.0 for CS303). The other hard one was the drop-course bug, because no tool flagged it at all. I only found it by reading the program output: "Open courses: 3" was wrong, since CS202 was full and nobody had enrolled in it, yet dropping it reopened it. Fixing it meant tracking who is enrolled in each course.

## 2. Did the static analysis tools report any false positives? If so, describe one example.

Partly. Bandit's B105 (hardcoded password) is rated only Low severity with Medium confidence because it guesses from the string content and variable name. Here it was a real problem, but the same check often fires on harmless strings such as default labels. B311 (random module) is similar: it would be a false positive if `random` were used for something like shuffling a list, but here it generated an OTP, so it was a genuine issue. Pylint's `global-statement` warning is more of a design opinion than a bug; the code worked, but removing it made the state easier to follow.

## 3. How would you integrate static analysis tools into your actual software development workflow?

- Run Flake8 and Pylint automatically on save in the editor, and as a pre-commit hook so badly formatted code never gets committed.
- Add a CI step (for example, a GitHub Actions workflow) that runs Pylint, Flake8 and Bandit on every pull request and fails the build if Bandit finds Medium/High issues or the Pylint score drops below a threshold such as 9.5.
- Keep a shared config (`.pylintrc`, `setup.cfg`) so the whole team uses the same rules, and only suppress a warning with an inline comment that explains why.
- Treat the tools as a first pass, not a replacement for tests and code review, since the most serious bug in this lab was a logic error none of them caught.

## 4. What tangible improvements did you observe in the code quality, readability, or potential robustness after applying the fixes?

- Security: no shell execution, no `eval`, a strong hash, a secure OTP, and no secret in the source or the output. Bandit went from 6 issues (2 High) to 0.
- Correctness: drops now only apply to enrolled students and refund the fee, enrollment checks remaining seats, the audit trail no longer leaks between calls, and errors are no longer silently swallowed. The open-course count is now correct (2 instead of 3).
- Readability: consistent snake_case names, docstrings on every function, simpler logic (`return not course["is_closed"]`, a one-line `sum` for open courses).
- Robustness: the roster file is closed safely with a context manager, and the module can be imported without running the demo.
- Pylint score improved from 4.00/10 to 10.00/10 and Flake8 reports nothing.
