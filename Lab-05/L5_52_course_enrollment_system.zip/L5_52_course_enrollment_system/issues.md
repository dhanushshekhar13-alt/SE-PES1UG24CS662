# Issues Found and Fixed

Line numbers refer to the original `course_enrollment_system.py`. Ordered by severity (high first).

| # | Issue | Tool / Code | Type | Severity | Line(s) | Description | Fix Approach |
|---|-------|-------------|------|----------|---------|-------------|--------------|
| 1 | Shell command injection | Bandit B605 | Security | High | 63 | `os.system("echo ... " + filename)` runs a shell command built from a parameter; a crafted filename could execute arbitrary commands. | Removed the shell call and used `print()` for the confirmation message. |
| 2 | Weak hash (MD5) | Bandit B324 | Security | High | 52 | MD5 is broken and unsuitable for hashing student identifiers. | Switched to `hashlib.sha256`. |
| 3 | Use of `eval()` | Bandit B307, Pylint W0123 | Security | Medium | 47 | `calculateScholarshipTuition` evaluates an arbitrary string, allowing code execution. | Function now takes a numeric `discount_rate` (0–1), validates it, and computes `fee * (1 - rate)`. |
| 4 | Hardcoded secret, printed to output | Bandit B105 | Security | Low (real impact high) | 75, 84 | Registrar token is hardcoded in source and then printed to the console. | Read the token from the `REGISTRAR_AUTH_TOKEN` environment variable; only print whether it is set. |
| 5 | Insecure random for OTP | Bandit B311 | Security | Low | 56 | `random.randint` is predictable, so OTPs can be guessed. | Use `secrets.randbelow(9000) + 1000`. |
| 6 | Bare `except: pass` | Bandit B110, Pylint W0702, Flake8 E722 | Bug | Low | 28–32 | Silently swallows every error (including typos and Ctrl-C); the caller never learns the drop failed. | Catch only `KeyError`/`ValueError` and return `False`; return `True` on success. |
| 7 | Mutable default argument | Pylint W0102 | Bug | Medium | 15 | `audit_trail=[]` is shared across all calls, so log entries leak between enrollments. | Default to `None` and create a new list inside the function. |
| 8 | Dropping a course nobody enrolled in reopens it | Not flagged by any tool | Logic bug | High | 27–30, 77 | `dropCourse("CS202")` added a seat to a full, closed course with no enrolled students, reopening it. Program printed "Open courses: 3" when only 2 were really open. | Track enrolled students per course; `drop_course(course_id, student_name)` only frees a seat for a student who is actually enrolled, and refunds the fee. |
| 9 | Enrollment does not check seat count | Not flagged by any tool | Logic bug | Medium | 17–19 | Only `is_closed` was checked, so seats could go negative if the flag was out of sync. | Also reject enrollment when `seats <= 0`. |
| 10 | Global statement for tuition total | Pylint W0603 | Quality | Medium | 12, 16 | `global total_tuition` makes state hard to track and test. | Store the running total in a module-level `LEDGER` dict; no `global` needed. |
| 11 | File opened without context manager / encoding | Pylint R1732, W1514 | Quality | Medium | 60–62 | File handle may leak if `write` fails; platform-dependent encoding. | `with open(filename, "w", encoding="utf-8") as roster_file:` |
| 12 | Unused import and variables | Flake8 F401/F841, Pylint W0611/W0612 | Quality | Low | 4, 36, 46, 68 | `math`, `lab_fee`, `base_fee` (after the eval fix it is used), `cid` were unused. | Removed them. |
| 13 | Shadowing outer name | Pylint W0621 | Quality | Low | 66 | Parameter `courses` hid the global `courses` dict. | Renamed parameter to `course_catalog`. |
| 14 | `== None` comparison | Flake8 E711, Pylint C0121 | Style | Low | 37 | Should use identity comparison. | `if course is None:` and simplified the if/else to `return not course["is_closed"]`. |
| 15 | Naming conventions | Pylint C0103 | Style | Low | 12, 15–66 | camelCase functions and lowercase module constant. | Renamed to snake_case functions and UPPER_CASE constants (`COURSES`, `ENROLLMENTS`, `LEDGER`). |
| 16 | Missing docstrings | Pylint C0114/C0116 | Style | Low | whole file | No module or function docstrings. | Added a module docstring and one per function. |
| 17 | Lines too long, no final newline | Flake8 E501/W292, Pylint C0301/C0304 | Style | Low | 7–9, 15, 23, 79, 87 | Lines exceeded 79 characters; file did not end with a newline. | Wrapped the course dict, function signature and f-string; added final newline. |
| 18 | `main()` runs on import | Code review | Quality | Low | 87 | Importing the module ran the whole demo. | Wrapped in `if __name__ == "__main__":`. |

## Results

| Tool | Before | After |
|------|--------|-------|
| Pylint | 4.00/10 | 10.00/10 |
| Bandit | 6 issues (2 High, 1 Medium, 3 Low) | 0 issues |
| Flake8 | 12 warnings | 0 warnings |

Reports are in `reports/before/` and `reports/after/`.
