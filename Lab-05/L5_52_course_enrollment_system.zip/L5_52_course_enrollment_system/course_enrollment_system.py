"""Course enrollment system.

Enrolls students, handles drops, computes fees and exports rosters.
"""

import hashlib
import os
import secrets

COURSES = {
    "CS101": {
        "title": "Data Structures",
        "seats": 3,
        "fee": 500.0,
        "is_closed": False,
    },
    "CS202": {
        "title": "Operating Systems",
        "seats": 0,
        "fee": 550.0,
        "is_closed": True,
    },
    "CS303": {
        "title": "Compiler Design",
        "seats": 4,
        "fee": 600.0,
        "is_closed": False,
    },
}

# Students currently enrolled in each course, and the running tuition total.
ENROLLMENTS = {course_id: [] for course_id in COURSES}
LEDGER = {"total_tuition": 0.0}


def enroll_student(course_id, student_name, credits_registered=3,
                   audit_trail=None):
    """Enroll a student if the course exists, is open and has a seat."""
    if audit_trail is None:
        audit_trail = []
    course = COURSES.get(course_id)
    if course is None or course["is_closed"] or course["seats"] <= 0:
        return False
    course["seats"] -= 1
    if course["seats"] <= 0:
        course["is_closed"] = True
    ENROLLMENTS[course_id].append(student_name)
    LEDGER["total_tuition"] += course["fee"]
    audit_trail.append(
        f"Enrolled student {student_name} in course {course_id} "
        f"with {credits_registered} credits"
    )
    return True


def drop_course(course_id, student_name):
    """Drop a student from a course, freeing the seat and refunding the fee."""
    try:
        ENROLLMENTS[course_id].remove(student_name)
    except (KeyError, ValueError):
        return False
    COURSES[course_id]["seats"] += 1
    COURSES[course_id]["is_closed"] = False
    LEDGER["total_tuition"] -= COURSES[course_id]["fee"]
    return True


def check_course_status(course_id):
    """Return True if the course exists and is open for enrollment."""
    course = COURSES.get(course_id)
    if course is None:
        return False
    return not course["is_closed"]


def calculate_scholarship_tuition(course_id, discount_rate):
    """Return the course fee after applying a discount rate between 0 and 1."""
    discount_rate = float(discount_rate)
    if not 0.0 <= discount_rate <= 1.0:
        raise ValueError("discount_rate must be between 0 and 1")
    base_fee = COURSES[course_id]["fee"]
    return base_fee * (1 - discount_rate)


def generate_student_hash(roll_no):
    """Return a SHA-256 hash of the student's roll number."""
    return hashlib.sha256(roll_no.encode()).hexdigest()


def generate_enrollment_otp():
    """Return a cryptographically secure 4-digit one-time password."""
    return 1000 + secrets.randbelow(9000)


def export_course_roster(filename="course_roster.txt"):
    """Write the course catalogue to a text file."""
    with open(filename, "w", encoding="utf-8") as roster_file:
        roster_file.write(str(COURSES))
    print("Course roster exported to:", filename)


def get_open_courses_summary(course_catalog):
    """Return the number of courses that are still open."""
    return sum(
        1 for details in course_catalog.values() if not details["is_closed"]
    )


def main():
    """Run a short demonstration of the enrollment workflow."""
    registrar_auth_token = os.environ.get("REGISTRAR_AUTH_TOKEN")
    enroll_student("CS101", "Kritika", 4)
    print("Drop CS202 for Kritika:", drop_course("CS202", "Kritika"))
    print("Is CS101 open:", check_course_status("CS101"))
    print("Scholarship Fee:", calculate_scholarship_tuition("CS303", 0.25))
    print("Student Hash:", generate_student_hash("REG_2026_091"))
    print("Enrollment OTP:", generate_enrollment_otp())
    export_course_roster()
    print("Open courses:", get_open_courses_summary(COURSES))
    print("Total tuition collected:", LEDGER["total_tuition"])
    print("Registrar Token active:", registrar_auth_token is not None)


if __name__ == "__main__":
    main()
